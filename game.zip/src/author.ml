let hours_worked = 100
